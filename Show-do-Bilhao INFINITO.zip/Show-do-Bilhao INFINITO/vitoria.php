<?php
	echo "<h1>VENCEDOR! GANHOU UM BILHAO DE DOLARES!</h1><br>";
?>

<!--Logout-->
<a href="/login.php"><button>Jogar Novamente</button></a>