<?php
	echo "<h1>PERDEDOR! GAME OVER!</h1><br>";
?>

<!--Logout-->
<a href="/login.php"><button>Jogar Novamente</button></a>