<head>
	<title>Show do Bilhão</title>
	<meta charset="utf-8">
</head>

<?php
	require_once 'Faker/src/autoload.php';
	
	$faker = Faker\Factory::create();
	$cor = $faker->hexcolor;
?>

<h1 style='color: <?=$cor?>;'>
	Show do Bilhão!!!
</h1>