<?php
	//Importa Faker
	require_once 'Faker/src/autoload.php';
	//Importa as classe do POO
	require 'classes.php';
	
	//Gera as informacoes aleatoriamente com o Faker
	$faker = Faker\Factory::create();
	
	//Abre arquivo de usuarios
	$arquivo = fopen("users.json", 'r');
	$arquivoDados = "";

	//Le o arquivo json
	while(!feof($arquivo)) {
		$arquivoDados .= fgets($arquivo);
	}

	//Decodifica JSON
	$arquivoDadosJSON = json_decode($arquivoDados);
	fclose($arquivo);
	
	//Gera X usuarios diferentes
	for($i = 0; $i < 100000; $i++) {
		$nome = $faker->name; //Gera nome
		$email = $faker->email; //Gera email valido
		$login = $faker->userName; //Gera um username
		$senha = $faker->password; //Gera senha

		//Transforma em objeto User
		$usuario = new User($nome, $email, $login, $senha);		
		
		//Adiciona usuario novo no arquivo
		array_push($arquivoDadosJSON, $usuario);
	}
	
	//Fecha arquivo
	$arquivo = fopen("users.json", 'w');
	fwrite($arquivo, json_encode($arquivoDadosJSON, JSON_PRETTY_PRINT));
	fclose($arquivo);
	
	//Redireciona
	header("location: login.php");
?>