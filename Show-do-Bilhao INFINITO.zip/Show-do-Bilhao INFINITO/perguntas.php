<?php
	//Importa Faker
	require_once 'Faker/src/autoload.php';
	require 'classes.php';

	//Cria instancia do Faker
	$faker = Faker\Factory::create();

	$objetos = array();
	$perguntas = array();
	$alternativas = array();
	$respostas = array();

	//Gera perguntas
	for($i = 0; $i < 10; $i++) {
		$questao = new stdClass();

		$questao->enunciado = $faker->sentence($nbWords = 7, $variableNbWords = true); //Gera o enunciado
		$questao->alternativas = $faker->words($nb = 5, $asText = false); //Gera as alternativas
		$questao->resposta = 0; //Resposta eh sempre a primeira

		//Coloca no vetor de objetos
		array_push($objetos, $questao);
		
		array_push($perguntas, $questao->enunciado);
		array_push($alternativas, $questao->alternativas);
		array_push($respostas, $questao->resposta);
	}
	

	//Funcao Carrega Pergunta
	function carregaPergunta($id) {
		global $objetos;

		return $objetos[$id];
	}
?>