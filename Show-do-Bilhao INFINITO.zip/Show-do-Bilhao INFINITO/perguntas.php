<?php
	//Importa Faker
	require_once 'Faker/src/autoload.php';
	require 'classes.php';

	//Cria instancia do Faker
	$faker = Faker\Factory::create();

	$objetos = array();
	$perguntas = array();
	$alternativas = array();
	$respostas = array();

	//Acessa dados das perguntas
	/*$arquivo = fopen("perguntas.json", 'r');
	$info = "";
	
	//Le o arquivo
	while(!feof($arquivo)) {
		$info .= fgets($arquivo);
	}
	
	//Decodifica JSON
	$infoJSON = json_decode($info);
	
	//Transforma em objetos e armazena nas variaveis
	for($i = 0; $i < count($infoJSON); $i++) {
		//Transforma em objeto
		$objeto = new Question($infoJSON[$i]->enunciado, $infoJSON[$i]->alternativas, $infoJSON[$i]->resposta);
		array_push($objetos, $objeto);
		
		array_push($perguntas, $objeto->enunciado);
		array_push($alternativas, $objeto->alternativas);
		array_push($respostas, $objeto->resposta);
	}*/

	//Gera perguntas
	for($i = 0; $i < 10; $i++) {
		$questao = new stdClass();

		$questao->enunciado = $faker->sentence($nbWords = 7, $variableNbWords = true); //Gera o enunciado
		$questao->alternativas = $faker->words($nb = 5, $asText = false); //Gera as alternativas
		$questao->resposta = 0; //Resposta eh sempre a primeira

		//Coloca no vetor de objetos
		array_push($objetos, $questao);
		
		array_push($perguntas, $questao->enunciado);
		array_push($alternativas, $questao->alternativas);
		array_push($respostas, $questao->resposta);
	}
	

	//Funcao Carrega Pergunta
	function carregaPergunta($id) {
		global $objetos;

		return $objetos[$id];
	}
?>