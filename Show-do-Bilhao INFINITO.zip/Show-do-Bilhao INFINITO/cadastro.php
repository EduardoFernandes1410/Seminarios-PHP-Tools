<?php include("menu.php"); ?>

<h3>Cadastro</h3>

<form action="cadastrar.php" method="post">
	Nome: <input type="text" name="nome"> <br>
	Email: <input type="email" name="email"> <br>
	Login: <input type="text" name="login"> <br>
	Senha: <input type="password" name="senha"> <br> <br>
	<input type="submit" name="submit" value="Cadastrar">
</form>


<?php include("rodape.inc"); ?>